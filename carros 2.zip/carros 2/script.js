const form = document.getElementById("carForm");

const carId = document.getElementById("carId");
const marca = document.getElementById("marca");
const modelo = document.getElementById("modelo");
const ano = document.getElementById("ano");
const preco = document.getElementById("preco");

const listaCarros = document.getElementById("listaCarros");

const btnSalvar = document.getElementById("btnSalvar");
const btnCancelar = document.getElementById("btnCancelar");


// Pega os carros salvos no navegador
let carros = JSON.parse(localStorage.getItem("carros")) || [];


// Mostra os carros na tela
function listarCarros() {

    listaCarros.innerHTML = "";

    if (carros.length === 0) {
        listaCarros.innerHTML = `
            <p class="vazio">
                Nenhum carro cadastrado.
            </p>
        `;

        return;
    }

    carros.forEach(function(carro) {

        const div = document.createElement("div");

        div.classList.add("carro");

        div.innerHTML = `
            <div class="carro-info">

                <h3>${carro.marca} ${carro.modelo}</h3>

                <p>
                    <strong>Ano:</strong> ${carro.ano}
                </p>

                <p class="preco">
                    R$ ${Number(carro.preco).toLocaleString("pt-BR")}
                </p>

            </div>

            <div class="acoes">

                <button
                    class="btn-editar"
                    onclick="editarCarro(${carro.id})">
                    Editar
                </button>

                <button
                    class="btn-excluir"
                    onclick="excluirCarro(${carro.id})">
                    Excluir
                </button>

            </div>
        `;

        listaCarros.appendChild(div);
    });
}


// Cadastrar ou atualizar carro
form.addEventListener("submit", function(event) {

    event.preventDefault();

    const id = carId.value;

    const carro = {
        id: id ? Number(id) : Date.now(),
        marca: marca.value,
        modelo: modelo.value,
        ano: ano.value,
        preco: preco.value
    };


    // Se existe ID, estamos editando
    if (id) {

        carros = carros.map(function(item) {

            if (item.id === Number(id)) {
                return carro;
            }

            return item;
        });

    } else {

        // Caso contrário, estamos cadastrando
        carros.push(carro);
    }


    salvarNoLocalStorage();

    listarCarros();

    limparFormulario();
});


// Editar carro
function editarCarro(id) {

    const carro = carros.find(function(item) {
        return item.id === id;
    });

    if (!carro) {
        return;
    }

    carId.value = carro.id;
    marca.value = carro.marca;
    modelo.value = carro.modelo;
    ano.value = carro.ano;
    preco.value = carro.preco;

    btnSalvar.textContent = "Atualizar";

    btnCancelar.style.display = "block";

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}


// Excluir carro
function excluirCarro(id) {

    const confirmar = confirm(
        "Tem certeza que deseja excluir este carro?"
    );

    if (!confirmar) {
        return;
    }

    carros = carros.filter(function(carro) {
        return carro.id !== id;
    });

    salvarNoLocalStorage();

    listarCarros();
}


// Salvar no localStorage
function salvarNoLocalStorage() {

    localStorage.setItem(
        "carros",
        JSON.stringify(carros)
    );
}


// Limpar formulário
function limparFormulario() {

    form.reset();

    carId.value = "";

    btnSalvar.textContent = "Cadastrar";

    btnCancelar.style.display = "none";
}


// Botão cancelar
btnCancelar.addEventListener("click", function() {
    limparFormulario();
});


// Inicializar sistema
listarCarros();
