let carros = JSON.parse(localStorage.getItem("carros")) || [];

const form = document.getElementById("formCarro");
const lista = document.getElementById("listaCarros");
const busca = document.getElementById("busca");


form.addEventListener("submit", function(event) {

    event.preventDefault();

    const id = document.getElementById("idCarro").value;
    const marca = document.getElementById("marca").value;
    const modelo = document.getElementById("modelo").value;
    const ano = document.getElementById("ano").value;
    const preco = document.getElementById("preco").value;
    const status = document.getElementById("status").value;

    if (id === "") {

        const novoCarro = {
            id: Date.now(),
            marca: marca,
            modelo: modelo,
            ano: ano,
            preco: preco,
            status: status
        };

        carros.push(novoCarro);

    } else {

        const carro = carros.find(carro => carro.id == id);

        carro.marca = marca;
        carro.modelo = modelo;
        carro.ano = ano;
        carro.preco = preco;
        carro.status = status;
    }

    salvarDados();

    form.reset();

    document.getElementById("idCarro").value = "";

    document.getElementById("btnSalvar").textContent = "Cadastrar";

    mostrarCarros();
});


function mostrarCarros() {

    lista.innerHTML = "";

    const textoBusca = busca.value.toLowerCase();

    const carrosFiltrados = carros.filter(carro =>
        carro.marca.toLowerCase().includes(textoBusca) ||
        carro.modelo.toLowerCase().includes(textoBusca)
    );

    carrosFiltrados.forEach(carro => {

        const div = document.createElement("div");

        div.classList.add("carro");

        div.innerHTML = `
            <h3>${carro.marca} ${carro.modelo}</h3>

            <p><strong>Ano:</strong> ${carro.ano}</p>

            <p><strong>Preço:</strong> R$ ${Number(carro.preco).toFixed(2)}</p>

            <p><strong>Status:</strong> ${carro.status}</p>

            <div class="botoes">
                <button class="editar" onclick="editarCarro(${carro.id})">
                    Editar
                </button>

                <button class="excluir" onclick="excluirCarro(${carro.id})">
                    Excluir
                </button>
            </div>
        `;

        lista.appendChild(div);
    });
}


function editarCarro(id) {

    const carro = carros.find(carro => carro.id === id);

    document.getElementById("idCarro").value = carro.id;
    document.getElementById("marca").value = carro.marca;
    document.getElementById("modelo").value = carro.modelo;
    document.getElementById("ano").value = carro.ano;
    document.getElementById("preco").value = carro.preco;
    document.getElementById("status").value = carro.status;

    document.getElementById("btnSalvar").textContent = "Salvar alterações";
}


function excluirCarro(id) {

    const confirmar = confirm("Deseja realmente excluir este carro?");

    if (!confirmar) {
        return;
    }

    carros = carros.filter(carro => carro.id !== id);

    salvarDados();

    mostrarCarros();
}


function salvarDados() {

    localStorage.setItem("carros", JSON.stringify(carros));
}


busca.addEventListener("input", mostrarCarros);

mostrarCarros();