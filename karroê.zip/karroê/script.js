let carros = JSON.parse(localStorage.getItem("carros")) || [];

const form = document.getElementById("formCarro");
const listaCarros = document.getElementById("listaCarros");


// CREATE
form.addEventListener("submit", function(event) {

    event.preventDefault();

    const carro = {
        id: Date.now(),
        marca: document.getElementById("marca").value,
        modelo: document.getElementById("modelo").value,
        ano: document.getElementById("ano").value,
        preco: document.getElementById("preco").value,
        quilometragem: document.getElementById("quilometragem").value,
        status: document.getElementById("status").value
    };

    carros.push(carro);

    salvarCarros();

    form.reset();

    listarCarros();
});


// READ
function listarCarros() {

    listaCarros.innerHTML = "";

    if (carros.length === 0) {
        listaCarros.innerHTML = "<p>Nenhum carro cadastrado.</p>";
        return;
    }

    carros.forEach(function(carro) {

        const div = document.createElement("div");

        div.classList.add("carro");

        div.innerHTML = `
            <h3>${carro.marca} ${carro.modelo}</h3>

            <p><strong>Ano:</strong> ${carro.ano}</p>

            <p><strong>Preço:</strong> R$ ${Number(carro.preco).toLocaleString("pt-BR")}</p>

            <p><strong>Quilometragem:</strong> ${carro.quilometragem} km</p>

            <p><strong>Status:</strong> ${carro.status}</p>

            <div class="botoes">
                <button class="btn-editar" onclick="editarCarro(${carro.id})">
                    Editar
                </button>

                <button class="btn-excluir" onclick="excluirCarro(${carro.id})">
                    Excluir
                </button>
            </div>
        `;

        listaCarros.appendChild(div);
    });
}


// UPDATE
function editarCarro(id) {

    const carro = carros.find(function(carro) {
        return carro.id === id;
    });

    if (!carro) {
        return;
    }

    document.getElementById("marca").value = carro.marca;
    document.getElementById("modelo").value = carro.modelo;
    document.getElementById("ano").value = carro.ano;
    document.getElementById("preco").value = carro.preco;
    document.getElementById("quilometragem").value = carro.quilometragem;
    document.getElementById("status").value = carro.status;

    excluirCarro(id);
}


// DELETE
function excluirCarro(id) {

    carros = carros.filter(function(carro) {
        return carro.id !== id;
    });

    salvarCarros();

    listarCarros();
}


// Salvar no localStorage
function salvarCarros() {

    localStorage.setItem("carros", JSON.stringify(carros));
}


// Mostrar carros quando abrir a página
listarCarros();

