<?php
$veiculos = [
    [
        'modelo' => 'Honda Civic Touring',
        'ano' => 2022,
        'km' => '31.500 km',
        'cambio' => 'Automático',
        'preco' => 152900,
        'imagem' => 'https://images.unsplash.com/photo-1670285030808-a5d86b1525d6?auto=format&fit=crop&w=1200&q=82',
        'alt' => 'Honda Civic azul estacionado próximo a uma ponte',
    ],
    [
        'modelo' => 'Jeep Compass Limited',
        'ano' => 2023,
        'km' => '18.200 km',
        'cambio' => 'Automático',
        'preco' => 174990,
        'imagem' => 'https://stellantis3.dam-broadcast.com/medias/domain12808/media102708/812581-okfplwisig-whr.jpg',
        'alt' => 'Jeep Compass branco em uma estrada cercada por árvores',
    ],
    [
        'modelo' => 'Toyota Corolla Altis',
        'ano' => 2021,
        'km' => '42.800 km',
        'cambio' => 'CVT',
        'preco' => 139900,
        'imagem' => 'https://images.unsplash.com/photo-1619682817481-e994891cd1f5?auto=format&fit=crop&w=1200&q=82',
        'alt' => 'Toyota Corolla branco fotografado à noite',
    ],
];

function moeda(float $valor): string
{
    return 'R$ ' . number_format($valor, 2, ',', '.');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="AutoPrime: encontre veículos selecionados para o seu próximo caminho.">
    <title>AutoPrime | Veículos selecionados</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/app.js" defer></script>
</head>
<body>
    <header class="cabecalho">
        <a class="marca" href="#inicio" aria-label="AutoPrime - página inicial">
            <span class="marca-simbolo">A</span>
            <span>AUTO<strong>PRIME</strong></span>
        </a>

        <button class="menu-botao" type="button" aria-expanded="false" aria-controls="menu-principal">
            <span></span><span></span><span></span>
            <span class="sr-only">Abrir menu</span>
        </button>

        <nav id="menu-principal" class="menu" aria-label="Navegação principal">
            <a href="#inicio">Início</a>
            <a href="#estoque">Estoque</a>
            <a href="#empresa">A empresa</a>
            <a class="menu-destaque" href="#contato">Fale conosco</a>
        </nav>
    </header>

    <main>
        <section class="hero" id="inicio">
            <div class="hero-conteudo">
                <p class="eyebrow">Seu próximo carro está aqui</p>
                <h1>Escolha o caminho.<br><span>Nós cuidamos do resto.</span></h1>
                <p class="hero-texto">Veículos selecionados, procedência verificada e uma negociação transparente do início ao fim.</p>
                <div class="hero-acoes">
                    <a class="botao botao-principal" href="#estoque">Ver veículos</a>
                    <a class="botao botao-secundario" href="#contato">Falar com consultor</a>
                </div>
                <ul class="hero-indicadores" aria-label="Diferenciais da AutoPrime">
                    <li><strong>100%</strong><span>vistoriados</span></li>
                    <li><strong>12 meses</strong><span>de garantia</span></li>
                    <li><strong>4,9/5</strong><span>avaliação</span></li>
                </ul>
            </div>
            <div class="hero-imagem" role="img" aria-label="Carro esportivo em um showroom moderno"></div>
        </section>

        <section class="secao estoque" id="estoque">
            <div class="secao-cabecalho">
                <div>
                    <p class="eyebrow">Seleção AutoPrime</p>
                    <h2>Destaques do estoque</h2>
                </div>
                <a class="link-seta" href="#estoque">Ver todos <span aria-hidden="true">→</span></a>
            </div>

            <div class="grade-veiculos">
                <?php foreach ($veiculos as $veiculo): ?>
                    <article class="veiculo-card">
                        <div class="veiculo-imagem">
                            <img src="<?= htmlspecialchars($veiculo['imagem']) ?>" alt="<?= htmlspecialchars($veiculo['alt']) ?>" loading="lazy">
                            <span class="selo">Disponível</span>
                        </div>
                        <div class="veiculo-conteudo">
                            <p class="veiculo-ano"><?= $veiculo['ano'] ?></p>
                            <h3><?= htmlspecialchars($veiculo['modelo']) ?></h3>
                            <ul class="veiculo-dados">
                                <li><?= htmlspecialchars($veiculo['km']) ?></li>
                                <li><?= htmlspecialchars($veiculo['cambio']) ?></li>
                            </ul>
                            <div class="veiculo-rodape">
                                <div><small>A partir de</small><strong><?= moeda($veiculo['preco']) ?></strong></div>
                                <a href="#contato" aria-label="Tenho interesse no <?= htmlspecialchars($veiculo['modelo']) ?>">Tenho interesse</a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="secao empresa" id="empresa">
            <div>
                <p class="eyebrow">Compra sem surpresa</p>
                <h2>Confiança também vem de fábrica.</h2>
            </div>
            <p>Antes de chegar ao nosso estoque, cada veículo passa por uma avaliação completa. Você recebe informações claras para decidir com segurança.</p>
        </section>

        <section class="contato" id="contato">
            <div>
                <p class="eyebrow">Atendimento personalizado</p>
                <h2>Encontrou o carro ideal?</h2>
                <p>Fale com nossa equipe e agende uma visita.</p>
            </div>
            <a class="botao botao-principal" href="mailto:contato@autoprime.com.br">Entrar em contato</a>
        </section>
    </main>

    <footer>
        <a class="marca" href="#inicio"><span class="marca-simbolo">A</span><span>AUTO<strong>PRIME</strong></span></a>
        <p>&copy; <?= date('Y') ?> AutoPrime. Projeto acadêmico.</p>
    </footer>
</body>
</html>
