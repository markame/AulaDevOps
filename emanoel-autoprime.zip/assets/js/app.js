const botaoMenu = document.querySelector('.menu-botao');
const menu = document.querySelector('.menu');

if (botaoMenu && menu) {
    botaoMenu.addEventListener('click', () => {
        const aberto = menu.classList.toggle('aberto');
        botaoMenu.setAttribute('aria-expanded', String(aberto));
    });

    menu.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => {
            menu.classList.remove('aberto');
            botaoMenu.setAttribute('aria-expanded', 'false');
        });
    });
}
